<?php
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PUT');
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
// require 'vendor/autoload.php';

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';
//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);
  $str_json = file_get_contents('php://input');
   $req_data = json_decode($str_json);
  $email = $req_data->email;
  $pdf_url = $req_data->pdf_url;


try {
    //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.hosts.co.uk';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'certificate@thediyschool.co.uk';                     //SMTP username
    $mail->Password   = 'guptes-tuFkag-kotni0';                               //SMTP password
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                     //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
$mail->SMTPDebug = 2;
    //Recipients
    $mail->setFrom('certificate@thediyschool.co.uk', 'DIY School');
    $mail->addAddress($email, 'Simon Bessell');     //Add a recipient
    // $mail->addAddress('ellen@example.com');               //Name is optional
    // $mail->addReplyTo('info@example.com', 'Information');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    //Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'DIY School certificate';
    $mail->Body    = '<p><a href="'.$pdf_url.'">Download certificate</a></p>';
    $mail->AltBody = 'DIY School certificate';

    $mail->send();
        echo json_encode(["message"=>'Message has been sent',"success"=>"true"]);
    } catch (Exception $e) {
        echo json_encode(["success"=>"false", "message","Message could not be sent. Mailer Error: {$mail->ErrorInfo}"]);
    }